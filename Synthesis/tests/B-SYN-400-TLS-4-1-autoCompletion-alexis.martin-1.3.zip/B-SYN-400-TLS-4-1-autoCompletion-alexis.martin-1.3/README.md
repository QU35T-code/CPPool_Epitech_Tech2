B-SYN-400-TLS-4-1-autoCompletion-alexis.martin

v1.0

* Simple parser
* The module that search can differentiate between cities and streets if they are multiple.
* Debug output added.

v1.1

* The search module has been optimized for the search for the city, the street as well as the number.
* Add anti crash in main function.

v1.2

* Add autocompletion module only for cities
* Add some units tests
* Remove debug output

v1.3

* Fix autocompletion module for cities
* Add autocompletion module for streets
* Add some debug commentary
* Fix crashes
* Add errors management
* Clean and add units tests